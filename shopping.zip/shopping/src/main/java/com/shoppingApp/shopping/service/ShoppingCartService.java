package com.shoppingApp.shopping.service;

import com.shoppingApp.shopping.StaticObject;
import com.shoppingApp.shopping.model.Order;
import com.shoppingApp.shopping.model.ShoppingCart;
import com.shoppingApp.shopping.repository.ShoppingCartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartService {

    @Autowired
    private ShoppingCartRepository shoppingCartRepository;

    public Double calculate(Order order) {
        Double totalAmount = 0.0;
        List<ShoppingCart> list1 = order.getShoppingCartlist();

        for(ShoppingCart sh : list1){
            int id = sh.getId();
            ShoppingCart tempShoppingCart = StaticObject.productlist.get(id);
            totalAmount = tempShoppingCart.getPrice() * sh.getQuantity();
            return totalAmount;

        }
        return null;
    }
}
