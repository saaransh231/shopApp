package com.shoppingApp.shopping;

import com.shoppingApp.shopping.model.ShoppingCart;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StaticObject {

    public static ArrayList<ShoppingCart> productlist = new ArrayList<ShoppingCart>();

       static {

           ShoppingCart shoppingCart1 = new ShoppingCart(1,"pencil",2,5.5);
           ShoppingCart shoppingCart2 = new ShoppingCart(2,"stationary pad",5,7.8);
           productlist.add(shoppingCart1);
           productlist.add(shoppingCart2);
       }


    }





